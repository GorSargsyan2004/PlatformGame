package gamestates;

import entities.Player;
import entities.Skeleton;
import levels.LevelManager;
import main.Game;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import static main.Game.GAME_HEIGHT;
import static main.Game.TILES_SIZE;

public class Playing extends State implements Statemethods{
    private LevelManager levelManager;

    // ENTITIES
    private Player player;
    private Skeleton skeleton;

    public Playing(Game game) {
        super(game);
        initClasses();
    }

    private void initClasses() {
        // Loading the level
        levelManager = new LevelManager(game);
        int[][] lvlData = levelManager.getCurrentLevel().getLevelData();

        // Entities
//        player = new Player(100, 20, new Point2D.Double(400.0, GAME_HEIGHT - 12*TILES_SIZE), Game.SCALE, lvlData);
        skeleton = new Skeleton(100, 20, new Point2D.Double(400.0, GAME_HEIGHT - 12*TILES_SIZE), Game.SCALE, lvlData);
    }

    @Override
    public void update() {
        levelManager.update();
//        player.update();
        skeleton.update();
    }

    @Override
    public void draw(Graphics g) {
        levelManager.draw(g);
        skeleton.draw(g);
//        player.draw(g);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
                player.setLeft(true);
                break;
            case KeyEvent.VK_D:
                player.setRight(true);
                break;
            case KeyEvent.VK_SPACE:
                player.setAttack(true);
                break;
            case KeyEvent.VK_W:
                player.setJump(true);
                break;
            case KeyEvent.VK_ESCAPE:
                Gamestate.state = Gamestate.MENU;
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
                player.setLeft(false);
                break;
            case KeyEvent.VK_D:
                player.setRight(false);
                break;
        }
    }
}
